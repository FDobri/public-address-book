--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4
-- Dumped by pg_dump version 13.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "public-address-book";
--
-- Name: public-address-book; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "public-address-book" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1250';


ALTER DATABASE "public-address-book" OWNER TO postgres;

\connect -reuse-previous=on "dbname='public-address-book'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Contact; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Contact" (
    "Id" integer NOT NULL,
    "Name" character varying(250) NOT NULL,
    "DateOfBirth" date NOT NULL,
    "Address" character varying(250) NOT NULL
);


ALTER TABLE public."Contact" OWNER TO postgres;

--
-- Name: PhoneNumber; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PhoneNumber" (
    "Id" integer NOT NULL,
    "Number" character varying(20) NOT NULL,
    "ContactId" integer NOT NULL
);


ALTER TABLE public."PhoneNumber" OWNER TO postgres;

--
-- Name: contact_contactid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contact_contactid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contact_contactid_seq OWNER TO postgres;

--
-- Name: contact_contactid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.contact_contactid_seq OWNED BY public."Contact"."Id";


--
-- Name: phonenumber_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.phonenumber_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.phonenumber_id_seq OWNER TO postgres;

--
-- Name: phonenumber_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.phonenumber_id_seq OWNED BY public."PhoneNumber"."Id";


--
-- Name: Contact Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Contact" ALTER COLUMN "Id" SET DEFAULT nextval('public.contact_contactid_seq'::regclass);


--
-- Name: PhoneNumber Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PhoneNumber" ALTER COLUMN "Id" SET DEFAULT nextval('public.phonenumber_id_seq'::regclass);


--
-- Data for Name: Contact; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Contact" ("Id", "Name", "DateOfBirth", "Address") FROM stdin;
\.
COPY public."Contact" ("Id", "Name", "DateOfBirth", "Address") FROM '$$PATH$$/2999.dat';

--
-- Data for Name: PhoneNumber; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PhoneNumber" ("Id", "Number", "ContactId") FROM stdin;
\.
COPY public."PhoneNumber" ("Id", "Number", "ContactId") FROM '$$PATH$$/3001.dat';

--
-- Name: contact_contactid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contact_contactid_seq', 52, true);


--
-- Name: phonenumber_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.phonenumber_id_seq', 66, true);


--
-- Name: PhoneNumber PhoneNumber_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PhoneNumber"
    ADD CONSTRAINT "PhoneNumber_pkey" PRIMARY KEY ("Id");


--
-- Name: PhoneNumber UQ_ContactID_Number; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PhoneNumber"
    ADD CONSTRAINT "UQ_ContactID_Number" UNIQUE ("ContactId", "Number");


--
-- Name: Contact UQ_Name_Address; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Contact"
    ADD CONSTRAINT "UQ_Name_Address" UNIQUE ("Name", "Address");


--
-- Name: Contact contact_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Contact"
    ADD CONSTRAINT contact_pkey PRIMARY KEY ("Id");


--
-- Name: PhoneNumber FK_PhoneNumber_Contact; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PhoneNumber"
    ADD CONSTRAINT "FK_PhoneNumber_Contact" FOREIGN KEY ("ContactId") REFERENCES public."Contact"("Id") NOT VALID;


--
-- PostgreSQL database dump complete
--

