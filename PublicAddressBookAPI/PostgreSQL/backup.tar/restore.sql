--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4
-- Dumped by pg_dump version 13.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "public-address-book";
--
-- Name: public-address-book; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "public-address-book" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1250';


ALTER DATABASE "public-address-book" OWNER TO postgres;

\connect -reuse-previous=on "dbname='public-address-book'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Contact; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Contact" (
    "ContactId" integer NOT NULL,
    "ContactName" character varying(250),
    "PhoneNumber" character varying(20),
    "City" character varying(50),
    "Country" character varying(50),
    "PostalNumber" character varying(20),
    "StreetAddress" character varying(100),
    "EmailAddress" character varying(500)
);


ALTER TABLE public."Contact" OWNER TO postgres;

--
-- Name: contact_contactid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contact_contactid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contact_contactid_seq OWNER TO postgres;

--
-- Name: contact_contactid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.contact_contactid_seq OWNED BY public."Contact"."ContactId";


--
-- Name: Contact ContactId; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Contact" ALTER COLUMN "ContactId" SET DEFAULT nextval('public.contact_contactid_seq'::regclass);


--
-- Data for Name: Contact; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Contact" ("ContactId", "ContactName", "PhoneNumber", "City", "Country", "PostalNumber", "StreetAddress", "EmailAddress") FROM stdin;
\.
COPY public."Contact" ("ContactId", "ContactName", "PhoneNumber", "City", "Country", "PostalNumber", "StreetAddress", "EmailAddress") FROM '$$PATH$$/2985.dat';

--
-- Name: contact_contactid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contact_contactid_seq', 3, true);


--
-- Name: Contact contact_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Contact"
    ADD CONSTRAINT contact_pkey PRIMARY KEY ("ContactId");


--
-- PostgreSQL database dump complete
--

